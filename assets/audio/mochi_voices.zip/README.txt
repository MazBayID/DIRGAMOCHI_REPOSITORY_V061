Format: IMA ADPCM (WAV format tag 0x11), 4-bit, mono, 16000 Hz, block size 256 bytes
Output ke MAX98357A: decode ke PCM 16-bit, I2S 16 kHz mono
Putar dari frame pertama animasi (10 fps).
